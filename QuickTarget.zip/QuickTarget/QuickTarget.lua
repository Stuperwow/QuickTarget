-- QuickTarget
-- Type a name into the box, press Enter, then click "Target" (or use the keybind)
-- to /target it and drop a raid marker on it. No macro window needed.
--
-- Targeting is a protected action, so the click goes through a secure button
-- whose macro text is rewritten whenever you change the name (out of combat).

local ADDON_NAME = ...

local MACRO_NAME = "QuickTarget"
local MACRO_ICON = 134400 -- question mark icon
local MAX_BODY   = 255    -- WoW macro length limit
local MARK_NAMES = { [0] = "No mark", "Star", "Circle", "Diamond", "Triangle", "Moon", "Square", "Cross", "Skull" }

-- Ping options, in cycle order. key = what goes after "/ping [@target]".
local PINGS = {
	{ key = "none",     label = "No ping" },
	{ key = "attack",   label = "Attack" },
	{ key = "warning",  label = "Warning" },
	{ key = "assist",   label = "Assist" },
	{ key = "onmyway",  label = "On My Way" },
	{ key = "ping",     label = "Ping" }, -- contextual ping
}
local function PingIndex(key)
	for i, p in ipairs(PINGS) do
		if p.key == key then return i end
	end
	return 1
end

BINDING_HEADER_QUICKTARGET = "QuickTarget"
_G["BINDING_NAME_CLICK QuickTargetButton:LeftButton"] = "Target the QuickTarget name"

local db
local pendingApply = false
local frame, editBox, markButton, pingButton, targetButton, statusText

local function Print(msg)
	print("|cff33ff99QuickTarget|r: " .. msg)
end

local function SetStatus(msg, r, g, b)
	if statusText then
		statusText:SetText(msg or "")
		statusText:SetTextColor(r or 0.8, g or 0.8, b or 0.8)
	end
end

-- Several names can be separated with ";" -- each gets its own /target line.
local function ParseNames(text)
	local names = {}
	for part in string.gmatch(text or "", "[^;]+") do
		part = strtrim(part)
		if part ~= "" then
			names[#names + 1] = part
		end
	end
	return names
end

local function BuildBody()
	local names = ParseNames(db.name)
	if #names == 0 then return nil end

	local lines = { "/cleartarget" }
	for _, n in ipairs(names) do
		lines[#lines + 1] = "/target " .. n
	end

	local m = db.mark or 0
	local ping = db.ping or "none"
	if m > 0 or ping ~= "none" then
		-- Don't mark or ping anything if the name wasn't found.
		lines[#lines + 1] = "/stopmacro [noexists][dead]"
	end
	if m > 0 then
		-- SetRaidTarget is protected since Midnight, so use the /tm slash command.
		-- /tm toggles, so clear first (/tm 0) and then set; pressing it twice keeps the mark.
		lines[#lines + 1] = "/tm 0"
		lines[#lines + 1] = "/tm " .. m
	end
	if ping == "ping" then
		lines[#lines + 1] = "/ping [@target]"
	elseif ping ~= "none" then
		lines[#lines + 1] = "/ping [@target] " .. ping
	end
	return table.concat(lines, "\n")
end

-- Keep the real macro (if you made one) in sync with the box.
local function SyncMacro(body)
	local idx = GetMacroIndexByName(MACRO_NAME)
	if not idx or idx == 0 then return false end
	local _, icon = GetMacroInfo(idx)
	EditMacro(idx, MACRO_NAME, icon or MACRO_ICON, body)
	return true
end

local function Apply()
	local body = BuildBody()
	if body and #body > MAX_BODY then
		SetStatus("Too long - macros max out at 255 characters.", 1, 0.3, 0.3)
		return
	end

	if InCombatLockdown() then
		pendingApply = true
		SetStatus("In combat - updates when combat ends.", 1, 0.8, 0)
		return
	end
	pendingApply = false

	targetButton:SetAttribute("macrotext", body or "")
	if body then
		targetButton:Enable()
		local synced = SyncMacro(body)
		SetStatus(synced and "Ready (macro updated too)." or "Ready.", 0.3, 1, 0.3)
	else
		targetButton:Disable()
		SetStatus("Type a name and press Enter.")
	end
end

local function MakeMacro()
	if InCombatLockdown() then
		Print("Can't create macros in combat.")
		return
	end
	local body = BuildBody()
	if not body then
		Print("Enter a name first.")
		return
	end
	if #body > MAX_BODY then
		Print("That's too long for one macro (255 characters).")
		return
	end

	local idx = GetMacroIndexByName(MACRO_NAME)
	if not idx or idx == 0 then
		local numAccount = GetNumMacros()
		if numAccount >= (MAX_ACCOUNT_MACROS or 120) then
			Print("Your general (account) macro slots are full.")
			return
		end
		idx = CreateMacro(MACRO_NAME, MACRO_ICON, body, nil)
	else
		SyncMacro(body)
	end

	if idx and idx > 0 then
		ClearCursor()
		PickupMacro(idx)
		Print("Macro '" .. MACRO_NAME .. "' is on your cursor - drop it on an action bar. It follows whatever is in the box from now on.")
		SetStatus("Ready (macro updated too).", 0.3, 1, 0.3)
	end
end

local function UpdateMarkIcon()
	if not markButton then return end
	local m = db.mark or 0
	if m > 0 then
		markButton.icon:SetTexture("Interface\\TargetingFrame\\UI-RaidTargetingIcon_" .. m)
		markButton.icon:SetDesaturated(false)
	else
		markButton.icon:SetTexture("Interface\\Buttons\\UI-GroupLoot-Pass-Up")
	end
end

local function UpdatePingButton()
	if not pingButton then return end
	pingButton:SetText(PINGS[PingIndex(db.ping)].label)
end

-- The window holds a secure button, so it can't be shown, hidden or moved in combat.
local function ToggleFrame(show)
	if InCombatLockdown() then
		Print("Can't show or hide the window in combat.")
		return
	end
	if show == nil then show = not frame:IsShown() end
	frame:SetShown(show)
	db.shown = show
end

local function AddTooltip(widget, title, text)
	widget:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText(title)
		if text then GameTooltip:AddLine(text, 1, 1, 1, true) end
		GameTooltip:Show()
	end)
	widget:SetScript("OnLeave", GameTooltip_Hide)
end

local function CreateUI()
	frame = CreateFrame("Frame", "QuickTargetFrame", UIParent, "BasicFrameTemplateWithInset")
	frame:SetSize(316, 116)
	frame:SetClampedToScreen(true)
	frame:SetMovable(true)
	frame:EnableMouse(true)
	frame:RegisterForDrag("LeftButton")
	frame:SetScript("OnDragStart", function(self)
		if not InCombatLockdown() then self:StartMoving() end
	end)
	frame:SetScript("OnDragStop", function(self)
		self:StopMovingOrSizing()
		local point, _, relPoint, x, y = self:GetPoint()
		db.pos = { point, relPoint, x, y }
	end)

	local p = db.pos
	if p then
		frame:SetPoint(p[1], UIParent, p[2], p[3], p[4])
	else
		frame:SetPoint("CENTER", UIParent, "CENTER", 0, 200)
	end

	if frame.TitleText then
		frame.TitleText:SetText("QuickTarget")
	else
		local title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
		title:SetPoint("TOP", 0, -5)
		title:SetText("QuickTarget")
	end

	if frame.CloseButton then
		frame.CloseButton:SetScript("OnClick", function() ToggleFrame(false) end)
	end

	-- Name box
	editBox = CreateFrame("EditBox", "QuickTargetEditBox", frame, "InputBoxTemplate")
	editBox:SetSize(168, 20)
	editBox:SetPoint("TOPLEFT", 20, -34)
	editBox:SetAutoFocus(false)
	editBox:SetMaxLetters(200)
	editBox:SetText(db.name or "")
	editBox:SetScript("OnEnterPressed", function(self)
		db.name = self:GetText()
		Apply()
		self:ClearFocus()
	end)
	editBox:SetScript("OnEscapePressed", function(self)
		self:SetText(db.name or "")
		self:ClearFocus()
	end)
	editBox:SetScript("OnEditFocusLost", function(self)
		if self:GetText() ~= (db.name or "") then
			db.name = self:GetText()
			Apply()
		end
	end)
	AddTooltip(editBox, "Name to target", "Press Enter to save. Separate several names with ;")

	-- Marker picker
	markButton = CreateFrame("Button", nil, frame)
	markButton:SetSize(22, 22)
	markButton:SetPoint("LEFT", editBox, "RIGHT", 10, 0)
	markButton.icon = markButton:CreateTexture(nil, "ARTWORK")
	markButton.icon:SetAllPoints()
	markButton:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square", "ADD")
	markButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	markButton:SetScript("OnClick", function(self, button)
		local step = (button == "RightButton") and -1 or 1
		db.mark = ((db.mark or 0) + step) % 9
		UpdateMarkIcon()
		Apply()
		if GameTooltip:IsOwned(self) then self:GetScript("OnEnter")(self) end
	end)
	markButton:SetScript("OnEnter", function(self)
		GameTooltip:SetOwner(self, "ANCHOR_TOP")
		GameTooltip:SetText("Marker: " .. MARK_NAMES[db.mark or 0])
		GameTooltip:AddLine("Left-click: next   Right-click: previous", 1, 1, 1, true)
		GameTooltip:Show()
	end)
	markButton:SetScript("OnLeave", GameTooltip_Hide)

	-- Ping picker
	pingButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
	pingButton:SetSize(80, 22)
	pingButton:SetPoint("LEFT", markButton, "RIGHT", 6, 0)
	pingButton:RegisterForClicks("LeftButtonUp", "RightButtonUp")
	pingButton:SetScript("OnClick", function(self, button)
		local step = (button == "RightButton") and -1 or 1
		local i = (PingIndex(db.ping) - 1 + step) % #PINGS + 1
		db.ping = PINGS[i].key
		UpdatePingButton()
		Apply()
	end)
	AddTooltip(pingButton, "Ping", "Left-click: next   Right-click: previous\nPings the target after it's found. Group members see it; solo, only you do.")

	-- Secure target button (also what the keybind clicks)
	targetButton = CreateFrame("Button", "QuickTargetButton", frame, "SecureActionButtonTemplate, UIPanelButtonTemplate")
	targetButton:SetSize(134, 24)
	targetButton:SetPoint("TOPLEFT", editBox, "BOTTOMLEFT", -6, -8)
	targetButton:SetText("Target")
	targetButton:RegisterForClicks("AnyUp", "AnyDown") -- template fires once, honoring the key-down setting
	targetButton:SetAttribute("type", "macro")
	AddTooltip(targetButton, "Target, mark + ping", "Keybind it under Options > Keybindings > AddOns > QuickTarget.")

	-- Make / refresh a real macro you can drag to a bar
	local macroButton = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
	macroButton:SetSize(134, 24)
	macroButton:SetPoint("LEFT", targetButton, "RIGHT", 8, 0)
	macroButton:SetText("Make Macro")
	macroButton:SetScript("OnClick", MakeMacro)
	AddTooltip(macroButton, "Make Macro", "Creates a general macro named '" .. MACRO_NAME .. "' and puts it on your cursor. It updates automatically when you change the name.")

	statusText = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
	statusText:SetPoint("BOTTOMLEFT", 14, 12)
	statusText:SetPoint("BOTTOMRIGHT", -14, 12)
	statusText:SetJustifyH("LEFT")

	frame:SetShown(db.shown)
end

SLASH_QUICKTARGET1 = "/qt"
SLASH_QUICKTARGET2 = "/quicktarget"
SlashCmdList.QUICKTARGET = function(msg)
	msg = strtrim(msg or "")
	local cmd, rest = msg:match("^(%S*)%s*(.-)$")
	cmd = (cmd or ""):lower()

	if msg == "" then
		ToggleFrame()
	elseif cmd == "help" then
		Print("/qt - show/hide window")
		Print("/qt <name> - set the name (use ; for several)")
		Print("/qt mark <0-8> - marker (8 = skull, 0 = none)")
		Print("/qt ping <none|attack|warning|assist|onmyway|ping> - ping type")
		Print("/qt macro - create/refresh the '" .. MACRO_NAME .. "' macro")
	elseif cmd == "mark" then
		local n = tonumber(rest)
		if n and n >= 0 and n <= 8 then
			db.mark = math.floor(n)
			UpdateMarkIcon()
			Apply()
			Print("Marker: " .. MARK_NAMES[db.mark])
		else
			Print("Usage: /qt mark 0-8 (8 = skull, 0 = none)")
		end
	elseif cmd == "ping" then
		local key = (rest or ""):lower():gsub("%s", "")
		local found
		for _, p in ipairs(PINGS) do
			if p.key == key then found = p end
		end
		if found then
			db.ping = found.key
			UpdatePingButton()
			Apply()
			Print("Ping: " .. found.label)
		else
			Print("Usage: /qt ping none | attack | warning | assist | onmyway | ping")
		end
	elseif cmd == "macro" then
		MakeMacro()
	else
		db.name = msg
		editBox:SetText(msg)
		Apply()
		Print("Name set to: " .. msg)
	end
end

local events = CreateFrame("Frame")
events:RegisterEvent("ADDON_LOADED")
events:RegisterEvent("PLAYER_LOGIN")
events:RegisterEvent("PLAYER_REGEN_ENABLED")
events:SetScript("OnEvent", function(self, event, arg1)
	if event == "ADDON_LOADED" and arg1 == ADDON_NAME then
		QuickTargetDB = QuickTargetDB or {}
		db = QuickTargetDB
		if db.mark == nil then db.mark = 8 end
		if db.shown == nil then db.shown = true end
		if db.ping == nil then db.ping = "attack" end
		db.name = db.name or ""
		CreateUI()
		UpdateMarkIcon()
		UpdatePingButton()
		self:UnregisterEvent("ADDON_LOADED")
	elseif event == "PLAYER_LOGIN" then
		Apply() -- macros are loaded by now, so the sync works
	elseif event == "PLAYER_REGEN_ENABLED" and pendingApply then
		Apply()
	end
end)
